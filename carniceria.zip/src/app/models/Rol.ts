export class Rol{
    id: number;
    nombre: string;
    descripcion: string;
    

    constructor() {
        this.id = 0;
        this.nombre = '';
        this.descripcion = '';
    }
}