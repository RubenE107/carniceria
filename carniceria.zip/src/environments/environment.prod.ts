export const environment = {
  production: true,
  API_URI: "http://18.216.84.250/api",

};
